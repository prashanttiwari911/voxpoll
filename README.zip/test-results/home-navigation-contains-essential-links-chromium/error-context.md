# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: home.spec.ts >> navigation contains essential links
- Location: tests\e2e\home.spec.ts:15:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('nav').locator('text=Join')
Expected: visible
Error: strict mode violation: locator('nav').locator('text=Join') resolved to 2 elements:
    1) <a href="/join" class="text-zinc-600 dark:text-zinc-300 hover:text-indigo-600 dark:hover:text-indigo-400 font-bold text-sm flex items-center gap-1.5 transition-colors">…</a> aka getByRole('link', { name: 'Join', exact: true })
    2) <a href="/join" class="text-zinc-700 font-bold text-sm">Join</a> aka getByText('Join').nth(1)

Call log:
  - Expect "toBeVisible" locator('nav').locator('text=Join') with timeout 5000ms
  - waiting for locator('nav').locator('text=Join')

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - region "Notifications alt+T"
  - generic [ref=e2]:
    - navigation [ref=e3]:
      - generic [ref=e5]:
        - link "VoTI" [ref=e7] [cursor=pointer]:
          - /url: /
        - generic [ref=e13]:
          - link "Explore" [ref=e14] [cursor=pointer]:
            - /url: /
          - link "Join" [ref=e15] [cursor=pointer]:
            - /url: /join
          - link "Help" [ref=e19] [cursor=pointer]:
            - /url: /help
          - button "Toggle Dark Mode" [ref=e20]
          - button "Sign In" [ref=e23]
    - main [ref=e24]:
      - generic [ref=e25]:
        - generic [ref=e27]:
          - generic [ref=e28]:
            - heading "YOUR VOICE. YOUR VOTE." [level=1] [ref=e29]: YOUR VOICE.YOUR VOTE.
            - paragraph [ref=e30]: Ask questions, collect opinions, and discover what people think in real time.
            - generic [ref=e31]:
              - link "Create a Poll" [ref=e32] [cursor=pointer]:
                - /url: /polls/new
              - link "Join a Poll" [ref=e36] [cursor=pointer]:
                - /url: /join
          - generic [ref=e38]:
            - img "People looking at analytics on screen" [ref=e40]
            - generic [ref=e41]: 👍
            - generic [ref=e47]: 📊
        - generic [ref=e54]:
          - heading "How VoTI Works" [level=2] [ref=e56]
          - generic [ref=e57]:
            - generic [ref=e58]:
              - generic [ref=e59]: "1"
              - heading "Create" [level=3] [ref=e60]
              - paragraph [ref=e61]: Create a question and add your voting options in seconds.
            - generic [ref=e62]:
              - generic [ref=e63]: "2"
              - heading "Share & Vote" [level=3] [ref=e64]
              - paragraph [ref=e65]: Share a link, poll code, or QR code and collect votes instantly.
            - generic [ref=e66]:
              - generic [ref=e67]: "3"
              - heading "Discover" [level=3] [ref=e68]
              - paragraph [ref=e69]: See live results update in real-time with demographic insights.
        - generic [ref=e71]:
          - generic [ref=e72]:
            - generic [ref=e73]: ✦ INTERACTIVE DEMO
            - heading "See how it works" [level=2] [ref=e74]
            - paragraph [ref=e75]: Click through the steps below to experience VoTI.
          - generic [ref=e76]:
            - generic [ref=e77]:
              - button "🔍 Step 1 Browse & Join" [ref=e78]:
                - generic [ref=e79]: 🔍
                - generic [ref=e80]:
                  - generic [ref=e81]: Step 1
                  - heading "Browse & Join" [level=3] [ref=e84]
              - button "🗳️ Step 2 Cast Your Vote" [ref=e87]:
                - generic [ref=e88]: 🗳️
                - generic [ref=e89]:
                  - generic [ref=e90]: Step 2
                  - heading "Cast Your Vote" [level=3] [ref=e92]
              - button "📊 Step 3 See Results" [ref=e95]:
                - generic [ref=e96]: 📊
                - generic [ref=e97]:
                  - generic [ref=e98]: Step 3
                  - heading "See Results" [level=3] [ref=e100]
              - button "Next Step" [ref=e103]
            - generic [ref=e108]:
              - generic [ref=e109]:
                - paragraph [ref=e110]: Entering a poll code…
                - generic [ref=e111]:
                  - generic [ref=e112]:
                    - generic [ref=e113]: V
                    - generic [ref=e115]: VoTI
                    - generic [ref=e116]: Join a Poll
                  - generic [ref=e117]:
                    - paragraph [ref=e118]: Enter Poll Code
                    - generic [ref=e119]: "84216"
                  - generic [ref=e120]: Join Poll →
              - generic [ref=e121]:
                - generic [ref=e122]:
                  - generic [ref=e123]: Education
                  - generic [ref=e124]: ● Live
                - heading "Which educational path will shape the next decade?" [level=4] [ref=e125]
        - generic [ref=e127]:
          - generic [ref=e128]:
            - generic [ref=e129]:
              - generic [ref=e130]: AI-ILLUSTRATED TUTORIALS
              - heading "Learn VoTI in minutes" [level=2] [ref=e133]
              - paragraph [ref=e134]: Quick visual guides to get you voting, creating, and analyzing like a pro.
            - link "More on YouTube" [ref=e135] [cursor=pointer]:
              - /url: https://www.youtube.com/results?search_query=online+poll+tutorial
          - generic [ref=e140]:
            - generic [ref=e141] [cursor=pointer]:
              - generic [ref=e142]:
                - img "How to Join a Live Poll" [ref=e143]
                - generic [ref=e145]: ✦ AI Illustrated
                - generic [ref=e150]: ~2 min
              - generic [ref=e151]:
                - generic [ref=e152]: Getting Started
                - heading "How to Join a Live Poll" [level=3] [ref=e153]
                - paragraph [ref=e154]: Enter a 5-digit code, scan a QR code, and cast your vote in seconds.
                - generic [ref=e155]: Watch tutorial
            - generic [ref=e159] [cursor=pointer]:
              - generic [ref=e160]:
                - img "Create Your First Poll in 60 Seconds" [ref=e161]
                - generic [ref=e163]: ✦ AI Illustrated
                - generic [ref=e168]: ~1 min
              - generic [ref=e169]:
                - generic [ref=e170]: Creating Polls
                - heading "Create Your First Poll in 60 Seconds" [level=3] [ref=e171]
                - paragraph [ref=e172]: Write a question, add options, choose a category, and go live instantly.
                - generic [ref=e173]: Watch tutorial
            - generic [ref=e177] [cursor=pointer]:
              - generic [ref=e178]:
                - img "Share Polls & Read Live Analytics" [ref=e179]
                - generic [ref=e181]: ✦ AI Illustrated
                - generic [ref=e186]: ~3 min
              - generic [ref=e187]:
                - generic [ref=e188]: Analytics
                - heading "Share Polls & Read Live Analytics" [level=3] [ref=e189]
                - paragraph [ref=e190]: Use QR codes and poll codes to gather responses, then explore demographic charts.
                - generic [ref=e191]: Watch tutorial
          - paragraph [ref=e195]: Thumbnails are AI-generated. Clicking opens a YouTube search in a new tab.
        - generic [ref=e196]:
          - generic [ref=e198]:
            - heading [level=2] [ref=e199]
            - paragraph [ref=e203]: Join the conversation
          - generic [ref=e204]:
            - generic [ref=e205]:
              - textbox "Search polls…" [ref=e210]
              - generic [ref=e211]:
                - button "All Categories" [ref=e212]
                - button "Education" [ref=e213]
                - button "Sports" [ref=e214]
                - button "Politics" [ref=e215]
                - button "Books" [ref=e216]
                - button "Technology" [ref=e217]
                - button "Health" [ref=e218]
                - button "Other" [ref=e219]
              - generic [ref=e220]:
                - generic [ref=e221]: "Sort:"
                - combobox [ref=e222] [cursor=pointer]:
                  - option "Newest" [selected]
                  - option "Most Active"
                  - option "Closing Soon"
            - generic [ref=e223]:
              - generic [ref=e224]:
                - generic [ref=e225]:
                  - generic [ref=e226]:
                    - generic [ref=e227]: Books
                    - generic [ref=e228]: ACTIVE
                  - heading "What is your absolute favorite reading format?" [level=4] [ref=e229]
                  - generic [ref=e230]: 4 options
                - generic [ref=e231]:
                  - generic [ref=e232]: 92 votes
                  - link "Participate" [ref=e240] [cursor=pointer]:
                    - /url: /polls/cmuhwbo1e000gzkxcmlhtonbj
              - generic [ref=e244]:
                - generic [ref=e245]:
                  - generic [ref=e246]:
                    - generic [ref=e247]: Politics
                    - generic [ref=e248]: ACTIVE
                  - heading "What should be the primary focus of urban development policies?" [level=4] [ref=e249]
                  - generic [ref=e250]: 4 options
                - generic [ref=e251]:
                  - generic [ref=e252]: 87 votes
                  - link "Participate" [ref=e260] [cursor=pointer]:
                    - /url: /polls/cmuhwbmpz000bzkxcclgcjzl7
              - generic [ref=e264]:
                - generic [ref=e265]:
                  - generic [ref=e266]:
                    - generic [ref=e267]: Sports
                    - generic [ref=e268]: ACTIVE
                  - heading "Which sport is expanding fastest in terms of popularity across India?" [level=4] [ref=e269]
                  - generic [ref=e270]: 4 options
                - generic [ref=e271]:
                  - generic [ref=e272]: 83 votes
                  - link "Participate" [ref=e280] [cursor=pointer]:
                    - /url: /polls/cmuhwblgq0006zkxcgksa2z4r
              - generic [ref=e284]:
                - generic [ref=e285]:
                  - generic [ref=e286]:
                    - generic [ref=e287]: Education
                    - generic [ref=e288]: ACTIVE
                  - heading "Which educational path is most crucial for students in the next decade?" [level=4] [ref=e289]
                  - generic [ref=e290]: 4 options
                - generic [ref=e291]:
                  - generic [ref=e292]: 90 votes
                  - link "Participate" [ref=e300] [cursor=pointer]:
                    - /url: /polls/cmuhwbk190001zkxca2yh7qd2
          - generic [ref=e304]:
            - generic [ref=e305]: Previous
            - generic [ref=e306]: Page 1 of 1
            - generic [ref=e307]: Next
        - generic [ref=e308]:
          - heading "Ready to ask your audience?" [level=2] [ref=e309]
          - link "Create your own poll" [ref=e310] [cursor=pointer]:
            - /url: /polls/new
        - generic [ref=e316]:
          - paragraph [ref=e317]: Developer Access
          - generic [ref=e318]:
            - generic [ref=e319]:
              - heading "Access VoTI" [level=3] [ref=e324]
              - paragraph [ref=e325]: Sign in to cast your ballot, launch new polls, and analyze live demographics!
            - generic [ref=e326]:
              - button "Continue with Google" [ref=e327]
              - generic [ref=e334]: or
              - generic [ref=e338]:
                - heading "Sign in with Email OTP" [level=4] [ref=e339]
                - paragraph [ref=e343]: Enter your email and we'll send a secure 6-digit code.
                - generic [ref=e344]:
                  - textbox "name@example.com" [ref=e345]
                  - button "Send Code" [disabled] [ref=e346]
              - generic [ref=e347]: or test locally
              - generic [ref=e352]:
                - heading "Developer Quick Sign-In" [level=4] [ref=e353]
                - paragraph [ref=e357]: No credentials needed. Sign in with any dummy email to test local SQLite database flows!
                - generic [ref=e358]:
                  - textbox "Name" [ref=e359]
                  - textbox "Email Address" [ref=e360]
                  - spinbutton "Age" [ref=e361]
                  - combobox [ref=e362]:
                    - option "Select State/Region" [selected]
                    - option "Andaman and Nicobar Islands"
                    - option "Andhra Pradesh"
                    - option "Arunachal Pradesh"
                    - option "Assam"
                    - option "Bihar"
                    - option "Chandigarh"
                    - option "Chhattisgarh"
                    - option "Dadra and Nagar Haveli"
                    - option "Daman and Diu"
                    - option "Delhi"
                    - option "Goa"
                    - option "Gujarat"
                    - option "Haryana"
                    - option "Himachal Pradesh"
                    - option "Jammu and Kashmir"
                    - option "Jharkhand"
                    - option "Karnataka"
                    - option "Kerala"
                    - option "Ladakh"
                    - option "Lakshadweep"
                    - option "Madhya Pradesh"
                    - option "Maharashtra"
                    - option "Manipur"
                    - option "Meghalaya"
                    - option "Mizoram"
                    - option "Nagaland"
                    - option "Odisha"
                    - option "Puducherry"
                    - option "Punjab"
                    - option "Rajasthan"
                    - option "Sikkim"
                    - option "Tamil Nadu"
                    - option "Telangana"
                    - option "Tripura"
                    - option "Uttar Pradesh"
                    - option "Uttarakhand"
                    - option "West Bengal"
                  - combobox [ref=e363]:
                    - option "Select Gender" [selected]
                    - option "Male"
                    - option "Female"
                    - option "Other"
                    - option "Prefer not to say"
                  - textbox "Occupation" [ref=e364]
                - button "Sign In as Test User" [disabled] [ref=e365]
              - generic [ref=e366]:
                - generic [ref=e367]: "One-Click Test Accounts:"
                - generic [ref=e368]:
                  - button "Aria Sharma 🎓 Age 22 • Delhi" [ref=e369]:
                    - generic [ref=e370]: Aria Sharma 🎓
                    - generic [ref=e371]: Age 22 • Delhi
                  - button "Kabir Patil ⚽ Age 34 • Mumbai" [ref=e372]:
                    - generic [ref=e373]: Kabir Patil ⚽
                    - generic [ref=e374]: Age 34 • Mumbai
                  - button "Siya Mishra ⚖️ Age 45 • Lucknow" [ref=e375]:
                    - generic [ref=e376]: Siya Mishra ⚖️
                    - generic [ref=e377]: Age 45 • Lucknow
                  - button "Rohan Das 📖 Age 19 • Bangalore" [ref=e378]:
                    - generic [ref=e379]: Rohan Das 📖
                    - generic [ref=e380]: Age 19 • Bangalore
  - contentinfo [ref=e381]:
    - generic [ref=e382]:
      - generic [ref=e383]:
        - generic [ref=e384]:
          - generic [ref=e385]: VoTI
          - paragraph [ref=e391]: Cast your vote. Make your voice heard. Real-time polls for everyone.
          - paragraph [ref=e392]: © 2026 VoTI. All rights reserved.
        - generic [ref=e393]:
          - heading "Platform" [level=4] [ref=e394]
          - list [ref=e395]:
            - listitem [ref=e396]:
              - link "Explore Polls" [ref=e397] [cursor=pointer]:
                - /url: /
            - listitem [ref=e398]:
              - link "Join a Poll" [ref=e399] [cursor=pointer]:
                - /url: /join
            - listitem [ref=e400]:
              - link "Create a Poll" [ref=e401] [cursor=pointer]:
                - /url: /polls/new
            - listitem [ref=e402]:
              - link "My Dashboard" [ref=e403] [cursor=pointer]:
                - /url: /dashboard
        - generic [ref=e404]:
          - heading "Support" [level=4] [ref=e405]
          - list [ref=e406]:
            - listitem [ref=e407]:
              - link "Help Center" [ref=e408] [cursor=pointer]:
                - /url: /help
            - listitem [ref=e409]:
              - link "Contact Us" [ref=e410] [cursor=pointer]:
                - /url: /help#contact
            - listitem [ref=e411]:
              - link "Give Feedback" [ref=e412] [cursor=pointer]:
                - /url: /help#feedback
            - listitem [ref=e413]:
              - link "FAQs" [ref=e414] [cursor=pointer]:
                - /url: /help
        - generic [ref=e415]:
          - heading "Company" [level=4] [ref=e416]
          - list [ref=e417]:
            - listitem [ref=e418]:
              - link "About VoTI" [ref=e419] [cursor=pointer]:
                - /url: "#"
            - listitem [ref=e420]:
              - link "Privacy Policy" [ref=e421] [cursor=pointer]:
                - /url: "#"
            - listitem [ref=e422]:
              - link "Terms of Service" [ref=e423] [cursor=pointer]:
                - /url: "#"
            - listitem [ref=e424]:
              - link "Cookie Policy" [ref=e425] [cursor=pointer]:
                - /url: "#"
      - generic [ref=e426]:
        - paragraph [ref=e427]: Made with 💖 for India and beyond.
        - generic [ref=e428]:
          - link "Help" [ref=e429] [cursor=pointer]:
            - /url: /help
          - link "Contact" [ref=e430] [cursor=pointer]:
            - /url: /help
          - link "Feedback" [ref=e431] [cursor=pointer]:
            - /url: /help
  - generic [ref=e436] [cursor=pointer]:
    - button "Open Next.js Dev Tools" [ref=e437]
    - generic [ref=e441]:
      - button "Open issues overlay" [ref=e442]:
        - generic [ref=e443]:
          - generic [aria-hidden] [ref=e444]: "0"
          - generic [ref=e445]: "1"
        - generic [ref=e446]: Issue
      - button "Collapse issues badge" [ref=e447]
  - alert [ref=e450]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test('homepage loads and displays hero text', async ({ page }) => {
  4  |   await page.goto('/');
  5  | 
  6  |   // Expect the main hero headline to be visible
  7  |   await expect(page.locator('h1')).toContainText('YOUR VOICE.');
  8  |   await expect(page.locator('h1')).toContainText('YOUR VOTE.');
  9  | 
  10 |   // Expect the 'Create a Poll' button to be present
  11 |   const createPollBtn = page.locator('text=Create a Poll').first();
  12 |   await expect(createPollBtn).toBeVisible();
  13 | });
  14 | 
  15 | test('navigation contains essential links', async ({ page }) => {
  16 |   await page.goto('/');
  17 | 
  18 |   const nav = page.locator('nav');
  19 |   await expect(nav.locator('text=Explore')).toBeVisible();
> 20 |   await expect(nav.locator('text=Join')).toBeVisible();
     |                                          ^ Error: expect(locator).toBeVisible() failed
  21 | });
  22 | 
```